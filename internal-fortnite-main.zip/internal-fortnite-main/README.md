# Fortnite Internal

# Features
- Box ESP
- Mouse Aimbot
- Snaplines
- Text on Player
- Dynamic FOV Circle (does nothing other than be dynamic currently)

# PLEASE!!
- lemme know what to add!!

# About this
- this is just an example, use it for fun. its not undetected and never will be. 
- please do not sell this you wont have happy customers.
