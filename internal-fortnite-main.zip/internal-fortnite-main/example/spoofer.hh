#define get_process_base (uint64_t)GetModuleHandleA(NULL)
