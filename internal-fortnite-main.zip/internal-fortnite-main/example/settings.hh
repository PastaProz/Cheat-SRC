namespace settings
{	
	bool draw_circle = true;
	bool esp = true;
	bool lines = true;
	bool draw_distance = true;
	bool text = true;
	bool aimbot = true;
	float fov_size = 5.f;
	float smooth = 5.f;
	bool vis_check = true;
}