﻿using System;

// Token: 0x02000010 RID: 16
public class OrangeHeapAttribute : Attribute
{
}
