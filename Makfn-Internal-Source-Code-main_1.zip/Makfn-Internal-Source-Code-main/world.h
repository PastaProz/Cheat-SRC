#pragma once

#include "stdafx.h"

namespace world {
	inline SDK::UCanvas* pCanvas;
	inline bool bIsValid = false;

}