# AnkrWareSelfLeakxD
Got scammed, tired of kids thinking there special pasting | Has vengance menu
https://cdn.discordapp.com/attachments/854207251823984670/867970775330721852/4.PNG
Made by trix
