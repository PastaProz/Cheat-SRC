#pragma once

#include <Windows.h>
#include <vector>
#include <cmath>

namespace Render {
	BOOLEAN Initialize();
}

