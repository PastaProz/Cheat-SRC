#include "icons.h"

void Active()
{
	ImGuiStyle* Style = &ImGui::GetStyle();
	Style->Colors[ImGuiCol_Button] = ImColor(25, 30, 34, 200);
	Style->Colors[ImGuiCol_ButtonActive] = ImColor(25, 30, 34, 200);
	Style->Colors[ImGuiCol_ButtonHovered] = ImColor(25, 30, 34, 200);
}
void Hovered()
{
	ImGuiStyle* Style = &ImGui::GetStyle();
	Style->Colors[ImGuiCol_Button] = ImColor(19, 22, 27, 200);
	Style->Colors[ImGuiCol_ButtonActive] = ImColor(19, 22, 27, 200);
	Style->Colors[ImGuiCol_ButtonHovered] = ImColor(19, 22, 27, 200);
}
ImVec2 pos;
ImDrawList* draw;


void Deco()
{
	pos = ImGui::GetWindowPos();
	draw = ImGui::GetWindowDrawList();
}
static int tabs;
ImFont* info = nullptr;
ImFont* iconfont = nullptr;
ImFont* iconfont_big = nullptr;
ImFont* info_big = nullptr;
ImFont* two = nullptr;
ImFont* three = nullptr;
ImFont* tabsf = nullptr;
ImFont* ee = nullptr;

void menuinit() {

	ImGui::StyleColorsDark();
	ImGuiStyle* style = &ImGui::GetStyle();
	style->Alpha = 1.f;
	style->WindowRounding = 0.f;
	style->FramePadding = ImVec2(4, 3);
	style->WindowPadding = ImVec2(8, 8);
	style->ItemInnerSpacing = ImVec2(4, 4);
	style->ItemSpacing = ImVec2(8, 5);
	style->FrameRounding = 4.f;
	style->ScrollbarSize = 2.f;
	style->ScrollbarRounding = 12.f;
	style->PopupRounding = 5.f;


	ImVec4* colors = ImGui::GetStyle().Colors;

	colors[ImGuiCol_ChildBg] = ImColor(24, 29, 59, 0);
	colors[ImGuiCol_Border] = ImVec4(255, 255, 255, 0);
	colors[ImGuiCol_FrameBg] = ImColor(25, 25, 33, 255);
	colors[ImGuiCol_FrameBgActive] = ImColor(25, 25, 33, 255);
	colors[ImGuiCol_FrameBgHovered] = ImColor(25, 25, 33, 255);
	colors[ImGuiCol_Header] = ImColor(43, 55, 227, 255);
	colors[ImGuiCol_HeaderActive] = ImColor(43, 55, 227, 255);
	colors[ImGuiCol_HeaderHovered] = ImColor(43, 55, 227, 255);
	colors[ImGuiCol_PopupBg] = ImColor(43, 55, 227, 255);
	colors[ImGuiCol_Button] = ImColor(160, 30, 30, 255);
	colors[ImGuiCol_ButtonHovered] = ImColor(190, 45, 35, 255);
	colors[ImGuiCol_ButtonActive] = ImColor(220, 60, 40, 255);
	

	ImGui::SetCursorPos(ImVec2(22, 40));
	ImGui::SetNextWindowSize({ 630, 433 });

	ImGui::Begin("Fortnite", 0, ImGuiWindowFlags_::ImGuiWindowFlags_NoResize | ImGuiWindowFlags_::ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar); {

		ImGui::SetCursorPos(ImVec2(19, 125));
		
		pos = ImGui::GetWindowPos();
		draw = ImGui::GetWindowDrawList();

		draw->AddRectFilled(ImVec2(pos), ImVec2(pos.x + 684, pos.y + 433), ImColor(13, 13, 13));
		draw->AddRectFilledMultiColor(ImVec2(pos), ImVec2(pos.x + 680, pos.y + 25), ImColor(23, 23, 23), ImColor(23, 23, 23), ImColor(13, 13, 13), ImColor(13, 13, 13));
		draw->AddRectFilled(ImVec2(pos.x + 14, pos.y + 30), ImVec2(pos.x + 674, pos.y + 423), ImColor(18, 18, 18));
		draw->AddRect(ImVec2(pos.x + 14, pos.y + 30), ImVec2(pos.x + 670, pos.y + 423), ImColor(5, 5, 5), 0.f, 0.f, 2.f);
		draw->AddRect(ImVec2(pos.x + 175, pos.y + 35), ImVec2(pos.x + 665, pos.y + 417), ImColor(5, 5, 5), 0, 0, 2.f);

		ImGui::SetCursorPos(ImVec2(38, 40));
		ImGui::PushFont(iconfont_big);
		ImGui::Text("E");
		ImGui::PopFont();
		ImGui::SetCursorPos(ImVec2(25, 55));
		ImGui::PushFont(info);
		ImGui::Text("Cumnite");
		ImGui::PopFont();

		ImGui::BeginGroup();

		if (ImGui::Tab("Aimbot", 0 == tabs))
			tabs = 0;
		if (ImGui::Tab("Visuals", 1 == tabs))
			tabs = 1;
		if (ImGui::Tab("Misc", 2 == tabs))
			tabs = 2;

		ImGui::EndGroup();


		if (tabs == 0)
		{
			ImGui::SetCursorPos(ImVec2(180, 30));
			ImGui::BeginChild("Aimbot", ImVec2(235, 382));
			{
				ImGui::SetCursorPos(ImVec2(10, 20));
				ImGui::BeginGroup();
				{
					ImGui::Checkbox(("Aimbot"), &Settings::MouseBot);
					ImGui::Checkbox("Aimbot FOV", &Settings::AimbotFOV);
					if (Settings::AimbotFOV) {
						ImGui::SliderFloat(("fov size"), &Settings::AimbotFOVSize, 10.f, 1000.f);
					}
					ImGui::EndGroup();
				}
				ImGui::EndChild();
				ImGui::SameLine(0.f, 10.f);
				ImGui::BeginChild("Other", ImVec2(235, 382));
				{
					ImGui::SetCursorPos(ImVec2(10, 10));
					ImGui::BeginGroup();
					{
						ImGui::Checkbox("Reticle (3 types)", &Settings::Crosshair);
						ImGui::Checkbox("Square FOV (2 types)", &Settings::SquareFOV);
						ImGui::Checkbox("Outlined FOV (2 types)", &Settings::SquareFOV);
					}
					ImGui::EndGroup();
				}
				ImGui::EndChild();
			}
		}
		if (tabs == 1)
		{
			ImGui::SetCursorPos(ImVec2(180, 30));
			ImGui::BeginChild("Player ESP", ImVec2(235, 382));
			{
				ImGui::SetCursorPos(ImVec2(10, 20));
				ImGui::BeginGroup();
				{
					ImGui::Checkbox(("Box ESP"), &Settings::BoxESP);
					if (Settings::BoxESP) {
						ImGui::Checkbox(("Line ESP"), &Settings::LineESP);
						ImGui::Checkbox(("Held Item ESP"), &Settings::HeldItemESP);
						ImGui::Checkbox(("Skeleton ESP"), &Settings::SkeletonESP);
					}
					ImGui::EndGroup();
				}
				ImGui::EndChild();
				ImGui::SameLine(0.f, 10.f);
				ImGui::BeginChild("Other", ImVec2(235, 382));
				{
					ImGui::SetCursorPos(ImVec2(10, 10));
					ImGui::BeginGroup();
					{
						ImGui::Checkbox("Self ESP", &Settings::SelfESP);
						ImGui::Checkbox(("Radar ESP"), &Settings::RadarESP);
					}
					ImGui::EndGroup();
				}
				ImGui::EndChild();
			}
		}

		if (tabs == 2)
		{
			ImGui::Checkbox("FOV Changer", &Settings::FOVChanger);
			ImGui::SliderFloat(("fov amount"), &Settings::FOVChangerAmt, 80.f, 180.f);
			ImGui::Checkbox("Outlined Watermark", &Settings::OutlinedWatermark);
		}


		ImGui::Text("fortnite internal private");
		ImGui::End();
	}
}
