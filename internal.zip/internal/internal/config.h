namespace Settings
{
	bool Menu = true;

	bool MouseBot = false;
	bool BoxESP = true;
	bool LineESP = true;
	bool RadarESP = true;
	bool HeldItemESP = true;
	bool SkeletonESP = false;

	bool FOVChanger = false;
	bool AimbotFOV = false;

	float RadarDistance = 60000.0f;
	float AimbotFOVSize = 1000.0f;
	float FOVChangerAmt = 180.0f;
	bool SelfESP = false;
	bool Crosshair = false;
	bool OutlinedWatermark = true;
	bool SquareFOV = false;
	float SquareSize = 30.f;
	bool OutlinedCircle = false;
	float OutlinedSize = 100.f;
}

