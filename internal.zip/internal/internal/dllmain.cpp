#include "scan.h"
#include "depend.h"
#include "config.h"
#include "Menu.h"

ID3D11Device* device = nullptr;
ID3D11DeviceContext* immediateContext = nullptr;
ID3D11RenderTargetView* renderTargetView = nullptr;

HRESULT(*presenth)(IDXGISwapChain* swapChain, UINT syncInterval, UINT flags) = nullptr;
HRESULT(*resizeh)(IDXGISwapChain* swapChain, UINT bufferCount, UINT width, UINT height, DXGI_FORMAT newFormat, UINT swapChainFlags) = nullptr;

WNDPROC oriWndProc = NULL;
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

int Screen_X, Screen_Y;

HWND hwnd = NULL;

bool menu = false;

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam) && menu == true)
	{
		return true;
	}
	return CallWindowProc(oriWndProc, hWnd, msg, wParam, lParam);
}


void BackgroundGradient(int x, int y, int w, int h, RGBA* color)
{
	ImGui::GetOverlayDrawList()->AddRectFilledMultiColor(ImVec2(x, y), ImVec2(x + w, y + h), ImGui::ColorConvertFloat4ToU32(ImVec4(color->R / 255.0, color->G / 255.0, color->B / 255.0, 1.00f)), ImGui::ColorConvertFloat4ToU32(ImVec4(color->R / 255.0, color->G / 255.0, color->B / 255.0, 1.00f)), 0, 0);
}

int X, Y;
ImFontConfig font_config;


static const ImWchar ranges[] =
{
	0x0020, 0x00FF, // Basic Latin + Latin Supplement
	0x0400, 0x044F, // Cyrillic
	0,
};


std::string string_To_UTF8(const std::string& str)
{
	int nwLen = ::MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, NULL, 0);

	wchar_t* pwBuf = new wchar_t[nwLen + 1];
	ZeroMemory(pwBuf, nwLen * 2 + 2);

	::MultiByteToWideChar(CP_ACP, 0, str.c_str(), str.length(), pwBuf, nwLen);

	int nLen = ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, -1, NULL, NULL, NULL, NULL);

	char* pBuf = new char[nLen + 1];
	ZeroMemory(pBuf, nLen + 1);

	::WideCharToMultiByte(CP_UTF8, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);

	std::string retStr(pBuf);

	delete[]pwBuf;
	delete[]pBuf;

	pwBuf = NULL;
	pBuf = NULL;

	return retStr;

}

void DrawLine(int x1, int y1, int x2, int y2, const ImVec4& color, int thickness)
{
	ImGui::GetOverlayDrawList()->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), ImGui::GetColorU32(color), thickness);
}

HRESULT present_hk(IDXGISwapChain* swapchain, UINT sync, UINT flags)
{
	if (!device)
	{
		ID3D11Texture2D* renderTarget = 0;
		ID3D11Texture2D* backBuffer = 0;
		D3D11_TEXTURE2D_DESC backBufferDesc = { 0 };
		swapchain->GetDevice(__uuidof(device), (PVOID*)&device);
		device->GetImmediateContext(&immediateContext);

		swapchain->GetBuffer(0, __uuidof(renderTarget), (PVOID*)&renderTarget);
		device->CreateRenderTargetView(renderTarget, nullptr, &renderTargetView);
		renderTarget->Release();
		swapchain->GetBuffer(0, __uuidof(ID3D11Texture2D), (PVOID*)&backBuffer);
		backBuffer->GetDesc(&backBufferDesc);

		Screen_X = backBufferDesc.Width;
		Screen_Y = backBufferDesc.Height;

		backBuffer->Release();
		if (!hwnd)
		{
			hwnd = FindWindowW(L"UnrealWindow", L"Fortnite  ");

			if (!hwnd)
				hwnd = GetForegroundWindow();
		}

		ImGuiIO& io = ImGui::GetIO(); (void)io;
		info = io.Fonts->AddFontFromFileTTF("C:/windows/fonts/arial.ttf", 14);
		info_big = io.Fonts->AddFontFromFileTTF("C:/windows/fonts/arial.ttf", 23);
		iconfont = io.Fonts->AddFontFromMemoryTTF((void*)icon, sizeof(icon), 35, &font_config, ranges);
		iconfont_big = io.Fonts->AddFontFromMemoryTTF((void*)icon, sizeof(icon), 70, &font_config, ranges);
		ee = io.Fonts->AddFontFromFileTTF("C:/windows/fonts/arial.ttf", 13.0f, &font_config, ranges);
		two = io.Fonts->AddFontFromFileTTF("C:/windows/fonts/arialbd.ttf", 13.0f);
		three = io.Fonts->AddFontFromFileTTF("C:/windows/fonts/arialbd.ttf", 15.0f);
		ImGui::GetIO().Fonts->AddFontFromFileTTF(("C:\\Windows\\Fonts\\arial.ttf"), 13.0f);

		X = (float)backBufferDesc.Width;
		Y = (float)backBufferDesc.Height;
		ImGui_ImplDX11_Init(hwnd, device, immediateContext);
		ImGui_ImplDX11_CreateDeviceObjects();
	}

	immediateContext->OMSetRenderTargets(1, &renderTargetView, nullptr);
	auto& window = BeginScene();

	static bool pressed = false;

	if (GetKeyState(VK_INSERT) & 0x8000) //change menu key here
		pressed = true;

	else if (!(GetKeyState(VK_INSERT) & 0x8000) && pressed) {  //change menu key here
		Settings::Menu = !Settings::Menu;
		pressed = false;
	}

	if (Settings::AimbotFOV)
	{
		window.DrawList->AddCircle(ImVec2(X / 2, Y / 2), Settings::AimbotFOVSize, ImColor(230, 230, 230, 220), 20, 1.0f);
	}

	if (Settings::OutlinedCircle);
	{
		window.DrawList->AddCircle(ImVec2(X / 2, Y / 2), Settings::AimbotFOVSize, ImColor(0, 0, 0, 255), 20, 3.0f);
		window.DrawList->AddCircle(ImVec2(X / 2, Y / 2), Settings::AimbotFOVSize, ImColor(230, 230, 230, 255), 20, 1.5f);
	}

	if (Settings::OutlinedWatermark)
	{
		window.DrawList->AddText(ImVec2(61, 100), ImColor(0, 0, 0, 200), "internal pub hiv#0347");
		window.DrawList->AddText(ImVec2(59, 100), ImColor(0, 0, 0, 200), "internal pub hiv#0347");
		window.DrawList->AddText(ImVec2(62, 100), ImColor(0, 0, 0, 200), "internal pub hiv#0347");
		window.DrawList->AddText(ImVec2(58, 100), ImColor(0, 0, 0, 200), "internal pub hiv#0347");
	}
	window.DrawList->AddText(ImVec2(60, 100), ImColor(198, 3, 252), "internal pub hiv#0347");

	float size1 = 3.0f;
	float size2 = 2.0f;

	if (Settings::Crosshair)
	{
		window.DrawList->AddCircleFilled(ImVec2(X / 2, Y / 2), size1, ImColor(0, 0, 0, 255), 120);
		window.DrawList->AddCircleFilled(ImVec2(X / 2, Y / 2), size2, ImColor(0, 255, 251, 200), 120);
	}
	if (Settings::Menu)
	{
		ImGui::GetOverlayDrawList()->AddRectFilled(ImGui::GetIO().MousePos, ImVec2(ImGui::GetIO().MousePos.x + 6.f, ImGui::GetIO().MousePos.y + 6.f), ImColor(255, 255, 255));
		menuinit();
	}



	EndScene(window);
	return presenth(swapchain, sync, flags);
}


HRESULT resize_hk(IDXGISwapChain* swapChain, UINT bufferCount, UINT width, UINT height, DXGI_FORMAT newFormat, UINT swapChainFlags) {
	ImGui_ImplDX11_Shutdown();
	renderTargetView->Release();
	immediateContext->Release();
	device->Release();
	device = nullptr;
	return resizeh(swapChain, bufferCount, width, height, newFormat, swapChainFlags);
}

ImGuiWindow& BeginScene() {
	ImGui_ImplDX11_NewFrame();
	ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
	ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
	ImGui::Begin("##scene", nullptr, ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoTitleBar);
	auto& io = ImGui::GetIO();
	ImGui::SetWindowPos(ImVec2(0, 0), ImGuiCond_Always);
	ImGui::SetWindowSize(ImVec2(io.DisplaySize.x, io.DisplaySize.y), ImGuiCond_Always);
	return *ImGui::GetCurrentWindow();
}

VOID EndScene(ImGuiWindow& window) {
	window.DrawList->PushClipRectFullScreen();
	ImGui::End();
	ImGui::PopStyleColor();
	ImGui::PopStyleVar(2);
	ImGui::Render();
}

VOID hook() {

	Sleep(1000);

	HWND window = FindWindow(0, (L"Fortnite  "));

	IDXGISwapChain* swapChain = nullptr;
	ID3D11Device* device = nullptr;
	ID3D11DeviceContext* context = nullptr;
	auto                 featureLevel = D3D_FEATURE_LEVEL_11_0;

	DXGI_SWAP_CHAIN_DESC sd = { 0 };
	sd.BufferCount = 1;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
	sd.OutputWindow = window;
	sd.SampleDesc.Count = 1;
	sd.Windowed = TRUE;

	if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, 0, 0, &featureLevel, 1, D3D11_SDK_VERSION, &sd, &swapChain, &device, nullptr, &context))) {
		MessageBox(0, (L"dx11 failed hook"), (L"fatal error"), MB_ICONERROR);
		return;
	}

	auto table = *reinterpret_cast<PVOID**>(swapChain);
	auto present = table[8];
	auto resize = table[13];

	context->Release();
	device->Release();
	swapChain->Release();

	MH_Initialize();

	MH_CreateHook(present, present_hk, reinterpret_cast<PVOID*>(&presenth));
	MH_EnableHook(present);

	MH_CreateHook(resize, resize_hk, reinterpret_cast<PVOID*>(&resizeh));
	MH_EnableHook(resize);

	Beep(400, 400);

	oriWndProc = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)WndProc);
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID reserved) {
	if (reason == DLL_PROCESS_ATTACH) {
		hook();
	}

	return TRUE;
}