#pragma once
#include <Windows.h>
#include <string>
#include <iostream>
#include <Psapi.h>
#include <fstream>
#include <vector>

#include "output.h"
#include "dumper.h"
