# luksius be like
This retard of luksius is scamming people with a "softaim" he mean a shit & detect external paste.
(he is selling that for 100$ the lifetime LOL)
imagine pasting Oracle in 2k21
